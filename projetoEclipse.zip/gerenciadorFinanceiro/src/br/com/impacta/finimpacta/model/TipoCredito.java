package br.com.impacta.finimpacta.model;

public enum TipoCredito {
	SALARIO,EXTRA,RENDIMENTOS;
}
