package br.com.impacta.finimpacta.model;

public enum TipoCredito implements TipoLancamento {
	SALARIO,EXTRA,RENDIMENTOS;
}
