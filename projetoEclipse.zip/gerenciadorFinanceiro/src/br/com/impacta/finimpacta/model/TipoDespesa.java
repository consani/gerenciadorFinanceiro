package br.com.impacta.finimpacta.model;

public enum TipoDespesa implements TipoLancamento{
	 ALIMENTA��O, MORADIA, CUIDADOS_PESSOAIS, LAZER, 
	 TRANSPORTE, INVESTIMENTOS, FINANCIAMENTOS, EDUCACAO, 
	 VESTUARIO, SA�DE, IMPOSTOS_TARIFAS, OUTROS;
	
}
