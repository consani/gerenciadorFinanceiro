package br.com.impacta.finimpacta.model;

public class Debito extends Lancamento{

	private TipoDespesa tipo;
}
