package br.com.impacta.finimpacta.model;

public class Credito extends Lancamento{
	
	private TipoCredito tipo;

}
