package br.com.impacta.finimpacta.model;

public interface TipoLancamento {

}
